To start the game run starter.py in Python 2.
THe commands are keyboard button oriented.
The file will fail if you are not using Python 2 and have pygame installed.
