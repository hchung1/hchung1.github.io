import pygame, time

game_screen_x = 800#Game Screen width
game_screen_y = 600#Game Screen Height

#Game screen size
GameImage = pygame.display.set_mode((game_screen_x,game_screen_y))
#Basic Clock
clock = pygame.time.Clock()
