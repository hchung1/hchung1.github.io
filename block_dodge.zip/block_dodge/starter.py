from main import center
center("u")
